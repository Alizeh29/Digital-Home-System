﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DigitalHome
{
    public partial class MasterBedroom : Form
    {
        private MainForm mainform;
        public MasterBedroom(MainForm mainform)
        {
            this.mainform = mainform;
            InitializeComponent();
        }

        private void btnAC_Click(object sender, EventArgs e)
        {
            ACForm form = new ACForm("masterbedroom AC");
            form.ShowDialog();
        }

        private void btnLight_Click(object sender, EventArgs e)
        {
            LightForm form = new LightForm("masterbedroom light");
            form.ShowDialog();
        }

        private void btnDoor_Click(object sender, EventArgs e)
        {
            DoorForm form = new DoorForm("masterbedroom door");
            form.ShowDialog();
        }

        private void btnWindow_Click(object sender, EventArgs e)
        {
            Window form = new Window("masterbedroom window");
            form.ShowDialog();
        }

        private void btnFaucet_Click(object sender, EventArgs e)
        {
            Faucet f = new Faucet("masterbedroom faucet");
            f.ShowDialog();
        }

        private void btnShower_Click(object sender, EventArgs e)
        {
            Shower shower = new Shower("masterbedroom shower");
            shower.ShowDialog();
        }

        private void btnBigWindow_Click(object sender, EventArgs e)
        {
            Window form = new Window("masterbedroom bigwindow");
            form.ShowDialog();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            mainform.Visible = true;
            Dispose();
        }

        private void MasterBedroom_Load(object sender, EventArgs e)
        {

        }
    }
}
