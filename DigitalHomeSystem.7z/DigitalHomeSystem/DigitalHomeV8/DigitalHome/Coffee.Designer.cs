﻿namespace DigitalHome
{
    partial class Coffee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBoxCoffee = new System.Windows.Forms.ComboBox();
            this.btnSetCoffee = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.LightCoral;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(83, 49);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(240, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "COFFEE MAKER";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(29, 121);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(175, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Choose coffee flavor";
            // 
            // comboBoxCoffee
            // 
            this.comboBoxCoffee.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCoffee.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxCoffee.FormattingEnabled = true;
            this.comboBoxCoffee.Items.AddRange(new object[] {
            "AMERICANO",
            "LATTE",
            "CHOCOLATE",
            "CAPPUCINO",
            "FREDO"});
            this.comboBoxCoffee.Location = new System.Drawing.Point(219, 118);
            this.comboBoxCoffee.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxCoffee.Name = "comboBoxCoffee";
            this.comboBoxCoffee.Size = new System.Drawing.Size(163, 28);
            this.comboBoxCoffee.TabIndex = 2;
            // 
            // btnSetCoffee
            // 
            this.btnSetCoffee.BackColor = System.Drawing.Color.SandyBrown;
            this.btnSetCoffee.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSetCoffee.Location = new System.Drawing.Point(133, 187);
            this.btnSetCoffee.Margin = new System.Windows.Forms.Padding(2);
            this.btnSetCoffee.Name = "btnSetCoffee";
            this.btnSetCoffee.Size = new System.Drawing.Size(134, 37);
            this.btnSetCoffee.TabIndex = 3;
            this.btnSetCoffee.Text = "MAKE COFFEE";
            this.btnSetCoffee.UseVisualStyleBackColor = false;
            this.btnSetCoffee.Click += new System.EventHandler(this.btnSetCoffee_Click);
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(11, 274);
            this.btnBack.Margin = new System.Windows.Forms.Padding(2);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(83, 29);
            this.btnBack.TabIndex = 4;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // Coffee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(410, 314);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnSetCoffee);
            this.Controls.Add(this.comboBoxCoffee);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Coffee";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Coffee";
            this.Load += new System.EventHandler(this.Coffee_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBoxCoffee;
        private System.Windows.Forms.Button btnSetCoffee;
        private System.Windows.Forms.Button btnBack;
    }
}