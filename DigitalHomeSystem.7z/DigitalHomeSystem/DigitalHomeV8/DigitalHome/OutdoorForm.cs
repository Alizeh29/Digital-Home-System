﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DigitalHome
{
    public partial class OutdoorForm : Form
    {
        private MainForm mainForm;

        public OutdoorForm(MainForm mainForm)
        {
            this.mainForm = mainForm;
            InitializeComponent();
        }

        private void btnLight_Click(object sender, EventArgs e)
        {
            LightForm form = new LightForm("outdoor light");
            form.ShowDialog();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            mainForm.Visible = true;
            Dispose();
        }

        private void btnDoor_Click(object sender, EventArgs e)
        {
            DoorForm form = new DoorForm("outdoor door");
            form.ShowDialog();
        }

        private void btnCamera_Click(object sender, EventArgs e)
        {
            CameraForm form = new CameraForm("outdoor camera");
            form.ShowDialog();
        }

        private void btnAlarm_Click(object sender, EventArgs e)
        {
            MusicForm form = new MusicForm("outdoor music");
            form.ShowDialog();
        }
    }
}
