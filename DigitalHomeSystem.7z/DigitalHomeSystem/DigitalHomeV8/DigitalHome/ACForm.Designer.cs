﻿namespace DigitalHome
{
    partial class ACForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSetTemp = new System.Windows.Forms.Button();
            this.btnACOff = new System.Windows.Forms.Button();
            this.btnACOn = new System.Windows.Forms.Button();
            this.lblHeader = new System.Windows.Forms.Label();
            this.txtTemp = new System.Windows.Forms.TextBox();
            this.btnBack = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnSetTemp
            // 
            this.btnSetTemp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSetTemp.Location = new System.Drawing.Point(45, 220);
            this.btnSetTemp.Name = "btnSetTemp";
            this.btnSetTemp.Size = new System.Drawing.Size(121, 37);
            this.btnSetTemp.TabIndex = 16;
            this.btnSetTemp.Text = "Set temp";
            this.btnSetTemp.UseVisualStyleBackColor = true;
            this.btnSetTemp.Click += new System.EventHandler(this.btnSetTemp_Click);
            // 
            // btnACOff
            // 
            this.btnACOff.BackColor = System.Drawing.Color.Red;
            this.btnACOff.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnACOff.Location = new System.Drawing.Point(216, 134);
            this.btnACOff.Name = "btnACOff";
            this.btnACOff.Size = new System.Drawing.Size(106, 39);
            this.btnACOff.TabIndex = 15;
            this.btnACOff.Text = "AC off";
            this.btnACOff.UseVisualStyleBackColor = false;
            this.btnACOff.Click += new System.EventHandler(this.btnACOff_Click);
            // 
            // btnACOn
            // 
            this.btnACOn.BackColor = System.Drawing.Color.LimeGreen;
            this.btnACOn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnACOn.Location = new System.Drawing.Point(45, 134);
            this.btnACOn.Name = "btnACOn";
            this.btnACOn.Size = new System.Drawing.Size(106, 39);
            this.btnACOn.TabIndex = 14;
            this.btnACOn.Text = "AC on";
            this.btnACOn.UseVisualStyleBackColor = false;
            this.btnACOn.Click += new System.EventHandler(this.btnACOn_Click);
            // 
            // lblHeader
            // 
            this.lblHeader.AutoSize = true;
            this.lblHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.lblHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeader.Location = new System.Drawing.Point(163, 57);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(52, 31);
            this.lblHeader.TabIndex = 13;
            this.lblHeader.Text = "AC";
            // 
            // txtTemp
            // 
            this.txtTemp.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTemp.Location = new System.Drawing.Point(216, 220);
            this.txtTemp.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtTemp.Multiline = true;
            this.txtTemp.Name = "txtTemp";
            this.txtTemp.Size = new System.Drawing.Size(106, 37);
            this.txtTemp.TabIndex = 17;
            this.txtTemp.TextChanged += new System.EventHandler(this.txtTemp_TextChanged);
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(11, 321);
            this.btnBack.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(106, 36);
            this.btnBack.TabIndex = 18;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // ACForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(397, 368);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.txtTemp);
            this.Controls.Add(this.btnSetTemp);
            this.Controls.Add(this.btnACOff);
            this.Controls.Add(this.btnACOn);
            this.Controls.Add(this.lblHeader);
            this.Name = "ACForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ACForm";
            this.Load += new System.EventHandler(this.ACForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSetTemp;
        private System.Windows.Forms.Button btnACOff;
        private System.Windows.Forms.Button btnACOn;
        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.TextBox txtTemp;
        private System.Windows.Forms.Button btnBack;
    }
}