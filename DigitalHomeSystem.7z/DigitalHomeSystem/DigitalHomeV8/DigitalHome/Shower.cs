﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DigitalHome
{
    public partial class Shower : Form
    {
        private string deviceName;
        public Shower(string deviceName)
        {
            this.deviceName = deviceName;
            InitializeComponent();
            initializeData();

            if (LoginForm.child)
            {
                rbtnHot.Enabled = false;
            }
        }

        private void initializeData()
        {
            string connetionString;
            SqlConnection cnn;
            connetionString = @"Data Source=alizeh\sqlexpress;Initial Catalog=dighome_db;Integrated Security=SSPI;";
            cnn = new SqlConnection(connetionString);
            cnn.Open();

            //select command
            SqlCommand command = new SqlCommand("Select DeviceID, Status, Value from [Device] where DeviceName=@DeviceName", cnn);

            command.Parameters.AddWithValue("@DeviceName", deviceName);

            // execute
            using (SqlDataReader reader = command.ExecuteReader())
            {
                if (reader.HasRows)
                {
                    if (reader.Read())
                    {
                        if (reader.GetInt32(1) == 0)
                        {//off
                            btnTurnOn.Enabled = false;
                            btnTurnOn.Enabled = true;
                        }
                        else
                        {//on
                            btnTurnoff.Enabled = true;
                            btnTurnoff.Enabled = false;
                        }

                        if (reader.GetString(2) == "0")
                        {
                            rbtnCold.Checked = true;
                        }
                        else if (reader.GetString(2) == "1")
                        {
                            rbtnMedium.Checked = true;
                        }
                        else
                        {
                            rbtnHot.Checked = true;
                        }
                    }
                }
            }

            //close connection
            cnn.Close();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        #region
        //Radio Button Checked
        private void rbtnCold_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtnCold.Checked == true)
            {
                rbtnMedium.Checked = false;
                rbtnHot.Checked = false;
            }
        }

        private void rbtnMedium_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtnMedium.Checked == true)
            {
                rbtnCold.Checked = false;
                rbtnHot.Checked = false;
            }
        }

        private void rbtnHot_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtnHot.Checked == true)
            {
                rbtnCold.Checked = false;
                rbtnMedium.Checked = false;
            }
        }
        #endregion

        private void btnTurnOn_Click(object sender, EventArgs e)
        {
            string connetionString;
            SqlConnection cnn;
            connetionString = @"Data Source=alizeh\sqlexpress;Initial Catalog=dighome_db;Integrated Security=SSPI;";
            cnn = new SqlConnection(connetionString);
            cnn.Open();

            //select command
            SqlCommand command = new SqlCommand("Update Device set Status = 1 where DeviceName=@DeviceName", cnn);

            command.Parameters.AddWithValue("@DeviceName", deviceName);

            if (command.ExecuteNonQuery() > 0)
            {
                MessageBox.Show("Updated successfully");

                btnTurnoff.Enabled = true;
                btnTurnOn.Enabled = false;
            }
            else
            {
                MessageBox.Show("Update failed");
            }

            //close connection
            cnn.Close();
        }

        private void btnTurnoff_Click(object sender, EventArgs e)
        {
            string connetionString;
            SqlConnection cnn;
            connetionString = @"Data Source=alizeh\sqlexpress;Initial Catalog=dighome_db;Integrated Security=SSPI;";
            cnn = new SqlConnection(connetionString);
            cnn.Open();

            //select command
            SqlCommand command = new SqlCommand("Update Device set Status = 0 where DeviceName=@DeviceName", cnn);

            command.Parameters.AddWithValue("@DeviceName", deviceName);

            if (command.ExecuteNonQuery() > 0)
            {
                MessageBox.Show("Updated successfully");

                btnTurnoff.Enabled = false;
                btnTurnOn.Enabled = true;
            }
            else
            {
                MessageBox.Show("Update failed");
            }

            //close connection
            cnn.Close();
        }

        private void btnSet_Click(object sender, EventArgs e)
        {
            string connetionString;
            SqlConnection cnn;
            connetionString = @"Data Source=alizeh\sqlexpress;Initial Catalog=dighome_db;Integrated Security=SSPI;";
            cnn = new SqlConnection(connetionString);
            cnn.Open();

            //select command
            SqlCommand command = new SqlCommand("Update Device set Value = @Value where DeviceName=@DeviceName", cnn);

            //COLD = 1
            //MEDIUM = 3
            //HOT = 5
            command.Parameters.AddWithValue("@DeviceName", deviceName);
            if (rbtnCold.Checked)
            {
                command.Parameters.AddWithValue("@Value", "1");
            }
            else if (rbtnMedium.Checked)
            {
                command.Parameters.AddWithValue("@Value", "3");
            }
            else
            {
                command.Parameters.AddWithValue("@Value", "5");
            }

            if (command.ExecuteNonQuery() > 0)
            {
                MessageBox.Show("Updated successfully");

                btnTurnoff.Enabled = false;
                btnTurnOn.Enabled = true;
            }
            else
            {
                MessageBox.Show("Update failed");
            }

            //close connection
            cnn.Close();
        }

        private void Shower_Load(object sender, EventArgs e)
        {

        }
    }
}
