﻿namespace DigitalHome
{
    partial class Window
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBack = new System.Windows.Forms.Button();
            this.btnlockoff = new System.Windows.Forms.Button();
            this.btnlockon = new System.Windows.Forms.Button();
            this.lblHeader = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(55, 254);
            this.btnBack.Margin = new System.Windows.Forms.Padding(2);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(106, 36);
            this.btnBack.TabIndex = 13;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnlockoff
            // 
            this.btnlockoff.BackColor = System.Drawing.Color.Red;
            this.btnlockoff.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlockoff.Location = new System.Drawing.Point(239, 139);
            this.btnlockoff.Name = "btnlockoff";
            this.btnlockoff.Size = new System.Drawing.Size(106, 39);
            this.btnlockoff.TabIndex = 12;
            this.btnlockoff.Text = "CLOSE";
            this.btnlockoff.UseVisualStyleBackColor = false;
            this.btnlockoff.Click += new System.EventHandler(this.btnlockoff_Click);
            // 
            // btnlockon
            // 
            this.btnlockon.BackColor = System.Drawing.Color.LimeGreen;
            this.btnlockon.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlockon.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnlockon.Location = new System.Drawing.Point(55, 139);
            this.btnlockon.Name = "btnlockon";
            this.btnlockon.Size = new System.Drawing.Size(106, 39);
            this.btnlockon.TabIndex = 11;
            this.btnlockon.Text = "OPEN";
            this.btnlockon.UseVisualStyleBackColor = false;
            this.btnlockon.Click += new System.EventHandler(this.btnlockon_Click);
            // 
            // lblHeader
            // 
            this.lblHeader.AutoSize = true;
            this.lblHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.lblHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeader.Location = new System.Drawing.Point(136, 45);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(133, 31);
            this.lblHeader.TabIndex = 10;
            this.lblHeader.Text = "WINDOW";
            // 
            // Window
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(421, 320);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnlockoff);
            this.Controls.Add(this.btnlockon);
            this.Controls.Add(this.lblHeader);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Window";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Window";
            this.Load += new System.EventHandler(this.Window_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnlockoff;
        private System.Windows.Forms.Button btnlockon;
        private System.Windows.Forms.Label lblHeader;
    }
}