﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DigitalHome
{

    public partial class RegisterForm : Form
    {

        private HomeForm homeForm;
        public RegisterForm(HomeForm homeForm)
        {
            this.homeForm = homeForm;
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            homeForm.Visible = true;
            Dispose();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            //beep sound
            Console.Beep();

            bool result = false;

            //validate user name, password
            if (txtUserName.Text == "")
            {
                MessageBox.Show("Please enter user name");
                return;
            }
            if (txtPassword.Text == "")
            {
                MessageBox.Show("Please enter password");
                return;
            }

            int digits = 0;
            int uppercases = 0;
            int lowercases = 0;

            foreach (var item in txtPassword.Text)
            {
                if (Char.IsDigit(item))
                {
                    digits += 1;
                }
                else if (Char.IsLower(item))
                {
                    lowercases += 1;
                }
                else if (Char.IsUpper(item))
                {
                    uppercases += 1;
                }
            }

            if (digits < 1 || lowercases < 1 || uppercases < 1)
            {
                MessageBox.Show("Password has to be at least 1 digit, 1 upper case and 1 character at minimum");
                return;
            }
            //connection to database
            string connetionString;
            SqlConnection cnn;
            connetionString = @"Data Source=alizeh\sqlexpress;Initial Catalog=dighome_db;Integrated Security=SSPI;";
            cnn = new SqlConnection(connetionString);
            cnn.Open();

            //select command
            SqlCommand command = new SqlCommand("Select UserId from [users] where UserName=@UserName", cnn);

            command.Parameters.AddWithValue("@UserName", txtUserName.Text);

            // execute
            using (SqlDataReader reader = command.ExecuteReader())
            {
                if (reader.HasRows)
                {
                    MessageBox.Show("User name already exists!");
                }
                else
                {
                    result = true;
                }
            }

            if (result)
            { //no duplicate


                command = new SqlCommand("Insert into Users (UserName, Password,UserType) values (@UserName, @Password,@UserType)", cnn);
                command.Parameters.AddWithValue("@UserName", txtUserName.Text);
                if (checkBoxKid.Checked == true)
                {
                    command.Parameters.AddWithValue("@UserType", "1");
                }
                else
                {
                    command.Parameters.AddWithValue("@UserType", "0");
                }
                string encryptedPass = "";
                using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
                {

                    //to hash bytes
                    byte[] hashBytes = md5.ComputeHash(System.Text.Encoding.ASCII.GetBytes(txtPassword.Text));

                    // to hex string
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < hashBytes.Length; i++)
                    {
                        sb.Append(hashBytes[i].ToString("X2"));
                    }
                    encryptedPass = sb.ToString();
                }

                command.Parameters.AddWithValue("@Password", encryptedPass);

                if (command.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("Registration successful");
                    result = true;
                }
                else
                {
                    MessageBox.Show("Registration failed");
                }

            }



            //close connection
            cnn.Close();

            if (result)//close form if success
            {
                homeForm.Visible = true;
                Dispose();
            }
        }

        private void txtUserName_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBoxKid_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void RegisterForm_Load(object sender, EventArgs e)
        {

        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }

        //show password code 
       
        private void checkBox1_CheckedChanged_1(object sender, EventArgs e)
        {
            txtPassword.PasswordChar = checkBox1.Checked ? '\0' : '*';
        }

        private void button1_Click(object sender, EventArgs e)
        {
           HelpForm form = new HelpForm(this);
           form.ShowDialog();

        }
    }
}
