﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading;

namespace DigitalHome
{
    public partial class FireAlarmForm : Form
    {
        System.Media.SoundPlayer player = new System.Media.SoundPlayer();
        /// <summary>
        /// device name
        /// </summary>

        private string deviceName;
        public FireAlarmForm(string deviceName)
        {
            InitializeComponent();

            this.deviceName = deviceName;
            player.SoundLocation = "smoke-detector-1.wav";
            //update GUI from database
            initializeData();      

        }

        /// <summary>
        /// update GUI from database
        /// </summary>
        private void initializeData()
        {
            string connetionString;
            SqlConnection cnn;
            connetionString = @"Data Source=alizeh\sqlexpress;Initial Catalog=dighome_db;Integrated Security=SSPI;";
            cnn = new SqlConnection(connetionString);
            cnn.Open();


            //select command
            SqlCommand command = new SqlCommand("Select DeviceID, Status, Value from [Device] where DeviceName=@DeviceName", cnn);

            command.Parameters.AddWithValue("@DeviceName", deviceName);

            // execute
            using (SqlDataReader reader = command.ExecuteReader())
            {
                if (reader.HasRows)
                {
                    if (reader.Read())
                    {
                        if (reader.GetInt32(1) == 0)
                        {//off
                            btnTurnoff.Enabled = false;
                            btnTurnon.Enabled = true;
                        }
                        else
                        {//on
                            btnTurnoff.Enabled = true;
                            btnTurnon.Enabled = false;
                        }
                    }
                }
            }

            //close connection
            cnn.Close();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void btnTurnoff_Click(object sender, EventArgs e)
        {
            string connetionString;
            SqlConnection cnn;
            connetionString = @"Data Source=alizeh\sqlexpress;Initial Catalog=dighome_db;Integrated Security=SSPI;";
            cnn = new SqlConnection(connetionString);
            cnn.Open();

            player.Stop();
            //select command
            SqlCommand command = new SqlCommand("Update Device set Status = 0 where DeviceName=@DeviceName", cnn);

            command.Parameters.AddWithValue("@DeviceName", deviceName);

            if (command.ExecuteNonQuery() > 0)
            {
                MessageBox.Show("Alarm turning off in 6 seconds");

                btnTurnoff.Enabled = false;
                btnTurnon.Enabled = true;
            }

            // MessageBox.Show("Door locking in 6 seconds");
            for (int i = 0; i <= 5; i++)
            {
                Console.Beep();
                Thread.Sleep(1000);
            }
            MessageBox.Show("Alarm turned off");



            //close connection
            cnn.Close();
        }

        private void btnTurnon_Click(object sender, EventArgs e)
        {
            string connetionString;
            SqlConnection cnn;
            connetionString = @"Data Source=alizeh\sqlexpress;Initial Catalog=dighome_db;Integrated Security=SSPI;";
            cnn = new SqlConnection(connetionString);
            cnn.Open();

            player.Play();
            //select command
            SqlCommand command = new SqlCommand("Update Device set Status = 1 where DeviceName=@DeviceName", cnn);

            command.Parameters.AddWithValue("@DeviceName", deviceName);

            if (command.ExecuteNonQuery() > 0)
            {
                MessageBox.Show("Smoke detected");

                btnTurnoff.Enabled = true;
                btnTurnon.Enabled = false;
            }
         //   else
          //  {
          //      MessageBox.Show("Update failed");
          //  }

            //close connection
            cnn.Close();      
        }

        private void FireAlarmForm_Load(object sender, EventArgs e)
        {
            
        }      

      
    }
}
