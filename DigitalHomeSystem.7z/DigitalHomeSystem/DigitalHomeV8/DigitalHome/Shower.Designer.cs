﻿namespace DigitalHome
{
    partial class Shower
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTurnoff = new System.Windows.Forms.Button();
            this.btnTurnOn = new System.Windows.Forms.Button();
            this.rbtnHot = new System.Windows.Forms.RadioButton();
            this.rbtnMedium = new System.Windows.Forms.RadioButton();
            this.rbtnCold = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnSet = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnTurnoff
            // 
            this.btnTurnoff.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTurnoff.Location = new System.Drawing.Point(171, 166);
            this.btnTurnoff.Margin = new System.Windows.Forms.Padding(2);
            this.btnTurnoff.Name = "btnTurnoff";
            this.btnTurnoff.Size = new System.Drawing.Size(57, 36);
            this.btnTurnoff.TabIndex = 11;
            this.btnTurnoff.Text = "OFF";
            this.btnTurnoff.UseVisualStyleBackColor = true;
            this.btnTurnoff.Click += new System.EventHandler(this.btnTurnoff_Click);
            // 
            // btnTurnOn
            // 
            this.btnTurnOn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTurnOn.Location = new System.Drawing.Point(78, 166);
            this.btnTurnOn.Margin = new System.Windows.Forms.Padding(2);
            this.btnTurnOn.Name = "btnTurnOn";
            this.btnTurnOn.Size = new System.Drawing.Size(58, 36);
            this.btnTurnOn.TabIndex = 10;
            this.btnTurnOn.Text = "ON";
            this.btnTurnOn.UseVisualStyleBackColor = true;
            this.btnTurnOn.Click += new System.EventHandler(this.btnTurnOn_Click);
            // 
            // rbtnHot
            // 
            this.rbtnHot.AutoSize = true;
            this.rbtnHot.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnHot.ForeColor = System.Drawing.Color.Red;
            this.rbtnHot.Location = new System.Drawing.Point(274, 119);
            this.rbtnHot.Margin = new System.Windows.Forms.Padding(2);
            this.rbtnHot.Name = "rbtnHot";
            this.rbtnHot.Size = new System.Drawing.Size(63, 24);
            this.rbtnHot.TabIndex = 9;
            this.rbtnHot.TabStop = true;
            this.rbtnHot.Text = "HOT";
            this.rbtnHot.UseVisualStyleBackColor = true;
            this.rbtnHot.CheckedChanged += new System.EventHandler(this.rbtnHot_CheckedChanged);
            // 
            // rbtnMedium
            // 
            this.rbtnMedium.AutoSize = true;
            this.rbtnMedium.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnMedium.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.rbtnMedium.Location = new System.Drawing.Point(173, 119);
            this.rbtnMedium.Margin = new System.Windows.Forms.Padding(2);
            this.rbtnMedium.Name = "rbtnMedium";
            this.rbtnMedium.Size = new System.Drawing.Size(99, 24);
            this.rbtnMedium.TabIndex = 8;
            this.rbtnMedium.TabStop = true;
            this.rbtnMedium.Text = "MEDIUM";
            this.rbtnMedium.UseVisualStyleBackColor = true;
            this.rbtnMedium.CheckedChanged += new System.EventHandler(this.rbtnMedium_CheckedChanged);
            // 
            // rbtnCold
            // 
            this.rbtnCold.AutoSize = true;
            this.rbtnCold.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnCold.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.rbtnCold.Location = new System.Drawing.Point(80, 119);
            this.rbtnCold.Margin = new System.Windows.Forms.Padding(2);
            this.rbtnCold.Name = "rbtnCold";
            this.rbtnCold.Size = new System.Drawing.Size(75, 24);
            this.rbtnCold.TabIndex = 7;
            this.rbtnCold.TabStop = true;
            this.rbtnCold.Text = "COLD";
            this.rbtnCold.UseVisualStyleBackColor = true;
            this.rbtnCold.CheckedChanged += new System.EventHandler(this.rbtnCold_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.LightCoral;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(132, 49);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 31);
            this.label1.TabIndex = 6;
            this.label1.Text = "SHOWER";
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(155, 220);
            this.btnBack.Margin = new System.Windows.Forms.Padding(2);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(85, 31);
            this.btnBack.TabIndex = 12;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnSet
            // 
            this.btnSet.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSet.Location = new System.Drawing.Point(277, 166);
            this.btnSet.Margin = new System.Windows.Forms.Padding(2);
            this.btnSet.Name = "btnSet";
            this.btnSet.Size = new System.Drawing.Size(57, 36);
            this.btnSet.TabIndex = 13;
            this.btnSet.Text = "SET";
            this.btnSet.UseVisualStyleBackColor = true;
            this.btnSet.Click += new System.EventHandler(this.btnSet_Click);
            // 
            // Shower
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 278);
            this.Controls.Add(this.btnSet);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnTurnoff);
            this.Controls.Add(this.btnTurnOn);
            this.Controls.Add(this.rbtnHot);
            this.Controls.Add(this.rbtnMedium);
            this.Controls.Add(this.rbtnCold);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Shower";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Shower";
            this.Load += new System.EventHandler(this.Shower_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnTurnoff;
        private System.Windows.Forms.Button btnTurnOn;
        private System.Windows.Forms.RadioButton rbtnHot;
        private System.Windows.Forms.RadioButton rbtnMedium;
        private System.Windows.Forms.RadioButton rbtnCold;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnSet;
    }
}