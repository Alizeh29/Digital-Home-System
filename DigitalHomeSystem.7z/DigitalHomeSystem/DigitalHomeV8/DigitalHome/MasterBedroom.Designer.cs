﻿namespace DigitalHome
{
    partial class MasterBedroom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBack = new System.Windows.Forms.Button();
            this.btnShower = new System.Windows.Forms.Button();
            this.btnFaucet = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnWindow = new System.Windows.Forms.Button();
            this.btnDoor = new System.Windows.Forms.Button();
            this.btnLight = new System.Windows.Forms.Button();
            this.btnAC = new System.Windows.Forms.Button();
            this.btnBigWindow = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnBack
            // 
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(346, 463);
            this.btnBack.Margin = new System.Windows.Forms.Padding(6);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(109, 40);
            this.btnBack.TabIndex = 26;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnShower
            // 
            this.btnShower.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShower.Location = new System.Drawing.Point(553, 255);
            this.btnShower.Name = "btnShower";
            this.btnShower.Size = new System.Drawing.Size(158, 77);
            this.btnShower.TabIndex = 25;
            this.btnShower.Text = "Shower";
            this.btnShower.UseVisualStyleBackColor = true;
            this.btnShower.Click += new System.EventHandler(this.btnShower_Click);
            // 
            // btnFaucet
            // 
            this.btnFaucet.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFaucet.Location = new System.Drawing.Point(333, 255);
            this.btnFaucet.Name = "btnFaucet";
            this.btnFaucet.Size = new System.Drawing.Size(144, 77);
            this.btnFaucet.TabIndex = 24;
            this.btnFaucet.Text = "Faucet";
            this.btnFaucet.UseVisualStyleBackColor = true;
            this.btnFaucet.Click += new System.EventHandler(this.btnFaucet_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.LightCoral;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(293, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(227, 31);
            this.label1.TabIndex = 23;
            this.label1.Text = "Master Bedroom";
            // 
            // btnWindow
            // 
            this.btnWindow.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWindow.Location = new System.Drawing.Point(117, 255);
            this.btnWindow.Name = "btnWindow";
            this.btnWindow.Size = new System.Drawing.Size(147, 77);
            this.btnWindow.TabIndex = 22;
            this.btnWindow.Text = "Window ";
            this.btnWindow.UseVisualStyleBackColor = true;
            this.btnWindow.Click += new System.EventHandler(this.btnWindow_Click);
            // 
            // btnDoor
            // 
            this.btnDoor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDoor.Location = new System.Drawing.Point(553, 143);
            this.btnDoor.Name = "btnDoor";
            this.btnDoor.Size = new System.Drawing.Size(158, 72);
            this.btnDoor.TabIndex = 21;
            this.btnDoor.Text = "Door";
            this.btnDoor.UseVisualStyleBackColor = true;
            this.btnDoor.Click += new System.EventHandler(this.btnDoor_Click);
            // 
            // btnLight
            // 
            this.btnLight.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLight.Location = new System.Drawing.Point(333, 143);
            this.btnLight.Name = "btnLight";
            this.btnLight.Size = new System.Drawing.Size(144, 67);
            this.btnLight.TabIndex = 20;
            this.btnLight.Text = "Lights";
            this.btnLight.UseVisualStyleBackColor = true;
            this.btnLight.Click += new System.EventHandler(this.btnLight_Click);
            // 
            // btnAC
            // 
            this.btnAC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAC.Location = new System.Drawing.Point(117, 143);
            this.btnAC.Name = "btnAC";
            this.btnAC.Size = new System.Drawing.Size(147, 67);
            this.btnAC.TabIndex = 19;
            this.btnAC.Text = "AC";
            this.btnAC.UseVisualStyleBackColor = true;
            this.btnAC.Click += new System.EventHandler(this.btnAC_Click);
            // 
            // btnBigWindow
            // 
            this.btnBigWindow.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBigWindow.Location = new System.Drawing.Point(308, 378);
            this.btnBigWindow.Name = "btnBigWindow";
            this.btnBigWindow.Size = new System.Drawing.Size(187, 65);
            this.btnBigWindow.TabIndex = 27;
            this.btnBigWindow.Text = "Big Window ";
            this.btnBigWindow.UseVisualStyleBackColor = true;
            this.btnBigWindow.Click += new System.EventHandler(this.btnBigWindow_Click);
            // 
            // MasterBedroom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(855, 534);
            this.Controls.Add(this.btnBigWindow);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnShower);
            this.Controls.Add(this.btnFaucet);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnWindow);
            this.Controls.Add(this.btnDoor);
            this.Controls.Add(this.btnLight);
            this.Controls.Add(this.btnAC);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "MasterBedroom";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MasterBedroom";
            this.Load += new System.EventHandler(this.MasterBedroom_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnShower;
        private System.Windows.Forms.Button btnFaucet;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnWindow;
        private System.Windows.Forms.Button btnDoor;
        private System.Windows.Forms.Button btnLight;
        private System.Windows.Forms.Button btnAC;
        private System.Windows.Forms.Button btnBigWindow;
    }
}