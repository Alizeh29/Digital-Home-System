﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DigitalHome
{
    public partial class HomeForm : Form
    {

        public static System.Timers.Timer timer = new System.Timers.Timer(6000); //6 seconds -> the security door will be closed.

        public HomeForm()
        {
            InitializeComponent();
            timer.Elapsed += OnTimedEvent;
        }

        private static void OnTimedEvent(Object source, System.Timers.ElapsedEventArgs e)
        {

            timer.Enabled = false;

            MessageBox.Show("The door automatically closed!");

            string connetionString;
            SqlConnection cnn;
            connetionString = @"Data Source=alizeh\sqlexpress;Initial Catalog=dighome_db;Integrated Security=SSPI;";
            cnn = new SqlConnection(connetionString);
            cnn.Open();

            //select command
            SqlCommand command = new SqlCommand("Update Device set Status = 0 where DeviceName=@DeviceName", cnn);

            command.Parameters.AddWithValue("@DeviceName", "outdoor door");

            if (command.ExecuteNonQuery() > 0)
            {
                
            }

            //close connection
            cnn.Close();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            RegisterForm form = new RegisterForm(this);
            form.ShowDialog();
            Visible = false;
            this.Show();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            LoginForm form = new LoginForm(this);
            form.ShowDialog();
            Visible = false;
            this.Show();
        }

        private void HomeForm_Load(object sender, EventArgs e)
        {

        }
    }
}
