﻿namespace DigitalHome
{
    partial class TVForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSetChannel = new System.Windows.Forms.Button();
            this.btnTVOff = new System.Windows.Forms.Button();
            this.btnTVOn = new System.Windows.Forms.Button();
            this.lblHeader = new System.Windows.Forms.Label();
            this.txtChannel = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnSetChannel
            // 
            this.btnSetChannel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSetChannel.Location = new System.Drawing.Point(59, 202);
            this.btnSetChannel.Name = "btnSetChannel";
            this.btnSetChannel.Size = new System.Drawing.Size(122, 39);
            this.btnSetChannel.TabIndex = 16;
            this.btnSetChannel.Text = "Set channel";
            this.btnSetChannel.UseVisualStyleBackColor = true;
            this.btnSetChannel.Click += new System.EventHandler(this.btnSetChannel_Click);
            // 
            // btnTVOff
            // 
            this.btnTVOff.BackColor = System.Drawing.Color.Red;
            this.btnTVOff.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTVOff.Location = new System.Drawing.Point(240, 137);
            this.btnTVOff.Name = "btnTVOff";
            this.btnTVOff.Size = new System.Drawing.Size(82, 39);
            this.btnTVOff.TabIndex = 15;
            this.btnTVOff.Text = "TV off";
            this.btnTVOff.UseVisualStyleBackColor = false;
            this.btnTVOff.Click += new System.EventHandler(this.btnTVOff_Click);
            // 
            // btnTVOn
            // 
            this.btnTVOn.BackColor = System.Drawing.Color.LimeGreen;
            this.btnTVOn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTVOn.Location = new System.Drawing.Point(59, 137);
            this.btnTVOn.Name = "btnTVOn";
            this.btnTVOn.Size = new System.Drawing.Size(89, 39);
            this.btnTVOn.TabIndex = 14;
            this.btnTVOn.Text = "TV on";
            this.btnTVOn.UseVisualStyleBackColor = false;
            this.btnTVOn.Click += new System.EventHandler(this.btnTVOn_Click);
            // 
            // lblHeader
            // 
            this.lblHeader.AutoSize = true;
            this.lblHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.lblHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeader.Location = new System.Drawing.Point(170, 46);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(49, 31);
            this.lblHeader.TabIndex = 13;
            this.lblHeader.Text = "TV";
            // 
            // txtChannel
            // 
            this.txtChannel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtChannel.Location = new System.Drawing.Point(240, 200);
            this.txtChannel.Margin = new System.Windows.Forms.Padding(2);
            this.txtChannel.Multiline = true;
            this.txtChannel.Name = "txtChannel";
            this.txtChannel.Size = new System.Drawing.Size(104, 41);
            this.txtChannel.TabIndex = 17;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(11, 307);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(98, 35);
            this.button1.TabIndex = 18;
            this.button1.Text = "Back";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // TVForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(408, 356);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtChannel);
            this.Controls.Add(this.btnSetChannel);
            this.Controls.Add(this.btnTVOff);
            this.Controls.Add(this.btnTVOn);
            this.Controls.Add(this.lblHeader);
            this.Name = "TVForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TVForm";
            this.Load += new System.EventHandler(this.TVForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSetChannel;
        private System.Windows.Forms.Button btnTVOff;
        private System.Windows.Forms.Button btnTVOn;
        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.TextBox txtChannel;
        private System.Windows.Forms.Button button1;
    }
}