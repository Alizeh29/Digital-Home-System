﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Timers;

namespace DigitalHome
{
    public partial class LoginForm : Form
    {
        private HomeForm homeForm;
        public static bool child = false;


        public LoginForm(HomeForm homeForm)
        {
            this.homeForm = homeForm;
            InitializeComponent();

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            homeForm.Visible = true;
            Dispose();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            //beep sound
            Console.Beep();

            bool result = false;

            //validate user name, password
            if (txtUserName.Text == "")
            {
                MessageBox.Show("Please enter user name");
                return;
            }
            if (txtPassword.Text == "")
            {
                MessageBox.Show("Please enter password");
                return;
            }


            string encryptedPass = "";
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {

                //to hash bytes
                byte[] hashBytes = md5.ComputeHash(System.Text.Encoding.ASCII.GetBytes(txtPassword.Text));

                // to hex string
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < hashBytes.Length; i++)
                {
                    sb.Append(hashBytes[i].ToString("X2"));
                }
                encryptedPass = sb.ToString();
            }

            string connetionString;
            SqlConnection cnn;
            connetionString = @"Data Source=alizeh\sqlexpress;Initial Catalog=dighome_db;Integrated Security=SSPI;";
            cnn = new SqlConnection(connetionString);
            cnn.Open();

            //select command
            SqlCommand command = new SqlCommand("Select UserId, UserType from [users] where UserName=@UserName and Password=@Password", cnn);
            command.Parameters.AddWithValue("@UserName", txtUserName.Text);
            command.Parameters.AddWithValue("@Password", encryptedPass);

            // execute
            using (SqlDataReader reader = command.ExecuteReader())
            {
                if (reader.HasRows)
                {
                    reader.Read();
                    child = reader.GetInt32(1) == 1;
                    result = true;
                }
            }

            //close connection
            cnn.Close();

            if (result)//close form if success
            {
                MainForm form = new MainForm(this);
                form.ShowDialog();
                Visible = false;
                this.Show();
            }
            else
            {
                MessageBox.Show("Invalid Username/ Password");
            }
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }

        //show password code 
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            txtPassword.PasswordChar = checkBox1.Checked ? '\0' : '*';
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }

        //show button
        private void checkBox1_CheckedChanged_1(object sender, EventArgs e)
        {
            txtPassword.PasswordChar = checkBox1.Checked ? '\0' : '*';
        }
    }
}
