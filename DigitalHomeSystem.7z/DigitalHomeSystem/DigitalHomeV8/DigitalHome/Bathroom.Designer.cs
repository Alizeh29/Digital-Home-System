﻿namespace DigitalHome
{
    partial class Bathroom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnWindow = new System.Windows.Forms.Button();
            this.btnBathroomDoor = new System.Windows.Forms.Button();
            this.btnBathRoomLights = new System.Windows.Forms.Button();
            this.btnBathroomAC = new System.Windows.Forms.Button();
            this.btnShower = new System.Windows.Forms.Button();
            this.btnFaucet = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.LightCoral;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(133, 32);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(139, 31);
            this.label1.TabIndex = 9;
            this.label1.Text = "Bathroom";
            // 
            // btnWindow
            // 
            this.btnWindow.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWindow.Location = new System.Drawing.Point(56, 172);
            this.btnWindow.Margin = new System.Windows.Forms.Padding(2);
            this.btnWindow.Name = "btnWindow";
            this.btnWindow.Size = new System.Drawing.Size(86, 37);
            this.btnWindow.TabIndex = 8;
            this.btnWindow.Text = "Window";
            this.btnWindow.UseVisualStyleBackColor = true;
            this.btnWindow.Click += new System.EventHandler(this.button4_Click);
            // 
            // btnBathroomDoor
            // 
            this.btnBathroomDoor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBathroomDoor.Location = new System.Drawing.Point(269, 92);
            this.btnBathroomDoor.Margin = new System.Windows.Forms.Padding(2);
            this.btnBathroomDoor.Name = "btnBathroomDoor";
            this.btnBathroomDoor.Size = new System.Drawing.Size(82, 37);
            this.btnBathroomDoor.TabIndex = 7;
            this.btnBathroomDoor.Text = "Door";
            this.btnBathroomDoor.UseVisualStyleBackColor = true;
            this.btnBathroomDoor.Click += new System.EventHandler(this.btnBathroomDoor_Click);
            // 
            // btnBathRoomLights
            // 
            this.btnBathRoomLights.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBathRoomLights.Location = new System.Drawing.Point(160, 94);
            this.btnBathRoomLights.Margin = new System.Windows.Forms.Padding(2);
            this.btnBathRoomLights.Name = "btnBathRoomLights";
            this.btnBathRoomLights.Size = new System.Drawing.Size(86, 35);
            this.btnBathRoomLights.TabIndex = 6;
            this.btnBathRoomLights.Text = "Lights";
            this.btnBathRoomLights.UseVisualStyleBackColor = true;
            this.btnBathRoomLights.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnBathroomAC
            // 
            this.btnBathroomAC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBathroomAC.Location = new System.Drawing.Point(56, 96);
            this.btnBathroomAC.Margin = new System.Windows.Forms.Padding(2);
            this.btnBathroomAC.Name = "btnBathroomAC";
            this.btnBathroomAC.Size = new System.Drawing.Size(86, 35);
            this.btnBathroomAC.TabIndex = 5;
            this.btnBathroomAC.Text = "AC";
            this.btnBathroomAC.UseVisualStyleBackColor = true;
            this.btnBathroomAC.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnShower
            // 
            this.btnShower.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShower.Location = new System.Drawing.Point(270, 172);
            this.btnShower.Margin = new System.Windows.Forms.Padding(2);
            this.btnShower.Name = "btnShower";
            this.btnShower.Size = new System.Drawing.Size(81, 37);
            this.btnShower.TabIndex = 11;
            this.btnShower.Text = "Shower";
            this.btnShower.UseVisualStyleBackColor = true;
            this.btnShower.Click += new System.EventHandler(this.btnShower_Click);
            // 
            // btnFaucet
            // 
            this.btnFaucet.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFaucet.Location = new System.Drawing.Point(160, 172);
            this.btnFaucet.Margin = new System.Windows.Forms.Padding(2);
            this.btnFaucet.Name = "btnFaucet";
            this.btnFaucet.Size = new System.Drawing.Size(88, 37);
            this.btnFaucet.TabIndex = 10;
            this.btnFaucet.Text = "Faucet";
            this.btnFaucet.UseVisualStyleBackColor = true;
            this.btnFaucet.Click += new System.EventHandler(this.btnFaucet_Click);
            // 
            // btnBack
            // 
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(12, 265);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(71, 29);
            this.btnBack.TabIndex = 18;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // Bathroom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(419, 306);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnShower);
            this.Controls.Add(this.btnFaucet);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnWindow);
            this.Controls.Add(this.btnBathroomDoor);
            this.Controls.Add(this.btnBathRoomLights);
            this.Controls.Add(this.btnBathroomAC);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Bathroom";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bathroom";
            this.Load += new System.EventHandler(this.Bathroom_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnWindow;
        private System.Windows.Forms.Button btnBathroomDoor;
        private System.Windows.Forms.Button btnBathRoomLights;
        private System.Windows.Forms.Button btnBathroomAC;
        private System.Windows.Forms.Button btnShower;
        private System.Windows.Forms.Button btnFaucet;
        private System.Windows.Forms.Button btnBack;
    }
}