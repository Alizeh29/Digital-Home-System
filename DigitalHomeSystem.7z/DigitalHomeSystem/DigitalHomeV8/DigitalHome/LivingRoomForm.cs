﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DigitalHome
{
    public partial class LivingRoomForm : Form
    {
        private MainForm mainForm;
        public LivingRoomForm(MainForm mainForm)
        {
            this.mainForm = mainForm;
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            mainForm.Visible = true;
            Dispose();
        }

        private void btnDoor_Click(object sender, EventArgs e)
        {
            DoorForm form = new DoorForm("livingroom door");
            form.ShowDialog();
        }

        private void btnLight_Click(object sender, EventArgs e)
        {
            LightForm form = new LightForm("livingroom light");
            form.ShowDialog();
        }

        private void btnTV_Click(object sender, EventArgs e)
        {
            TVForm form = new TVForm("livingroom TV");
            form.ShowDialog();
        }

        private void btnFireAlarm_Click(object sender, EventArgs e)
        {
            FireAlarmForm form = new FireAlarmForm("living room firealarm");
            form.ShowDialog();
        }

        private void btnAC_Click(object sender, EventArgs e)
        {
            ACForm form = new ACForm("livingroom AC");
            form.ShowDialog();
        }

        private void btnMusic_Click(object sender, EventArgs e)
        {
            MusicForm form = new MusicForm("livingroom Music");
            form.ShowDialog();
        }
    }
}
