﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DigitalHome
{
    public partial class Coffee : Form
    {
        private string deviceName;
        public Coffee(string deviceName)
        {
            this.deviceName = deviceName;
            InitializeComponent();

            if (LoginForm.child)
            {
                btnSetCoffee.Enabled = false;
                comboBoxCoffee.Enabled = false;
            }
        }

        private void initializeData()
        {
            string connetionString;
            SqlConnection cnn;
            connetionString = @"Data Source=alizeh\sqlexpress;Initial Catalog=dighome_db;Integrated Security=SSPI;";
            cnn = new SqlConnection(connetionString);
            cnn.Open();

            //select command
            SqlCommand command = new SqlCommand("Select DeviceID, Status, Value from [Device] where DeviceName=@DeviceName", cnn);
            
            command.Parameters.AddWithValue("@DeviceName", deviceName);
            //close connection
            cnn.Close();
        }


        private void btnSetCoffee_Click(object sender, EventArgs e)
        {
            string connetionString;
            SqlConnection cnn;
            connetionString = @"Data Source=alizeh\sqlexpress;Initial Catalog=dighome_db;Integrated Security=SSPI;";
            cnn = new SqlConnection(connetionString);
            cnn.Open();

            SqlCommand command = new SqlCommand("Update Device set Value = @Value where DeviceName=@DeviceName ", cnn);

            command.Parameters.AddWithValue("@Value", comboBoxCoffee.SelectedItem.ToString());
            command.Parameters.AddWithValue("@DeviceName", deviceName);

            if (command.ExecuteNonQuery() > 0)
            {
                MessageBox.Show("Updated successfully");
            }
            else
            {
                MessageBox.Show("Update failed");
            }

            //close connection
            cnn.Close();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void Coffee_Load(object sender, EventArgs e)
        {

        }
    }
}
