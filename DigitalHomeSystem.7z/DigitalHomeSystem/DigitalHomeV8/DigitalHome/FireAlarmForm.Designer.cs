﻿namespace DigitalHome
{
    partial class FireAlarmForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTurnoff = new System.Windows.Forms.Button();
            this.btnTurnon = new System.Windows.Forms.Button();
            this.lblHeader = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnTurnoff
            // 
            this.btnTurnoff.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTurnoff.Location = new System.Drawing.Point(227, 124);
            this.btnTurnoff.Name = "btnTurnoff";
            this.btnTurnoff.Size = new System.Drawing.Size(106, 39);
            this.btnTurnoff.TabIndex = 11;
            this.btnTurnoff.Text = "Turn off";
            this.btnTurnoff.UseVisualStyleBackColor = true;
            this.btnTurnoff.Click += new System.EventHandler(this.btnTurnoff_Click);
            // 
            // btnTurnon
            // 
            this.btnTurnon.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTurnon.Location = new System.Drawing.Point(40, 124);
            this.btnTurnon.Name = "btnTurnon";
            this.btnTurnon.Size = new System.Drawing.Size(106, 39);
            this.btnTurnon.TabIndex = 10;
            this.btnTurnon.Text = "Test";
            this.btnTurnon.UseVisualStyleBackColor = true;
            this.btnTurnon.Click += new System.EventHandler(this.btnTurnon_Click);
            // 
            // lblHeader
            // 
            this.lblHeader.AutoSize = true;
            this.lblHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.lblHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeader.Location = new System.Drawing.Point(123, 34);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(145, 31);
            this.lblHeader.TabIndex = 9;
            this.lblHeader.Text = "Fire Alarm ";
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(11, 322);
            this.btnBack.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(106, 35);
            this.btnBack.TabIndex = 12;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // FireAlarmForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(397, 368);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnTurnoff);
            this.Controls.Add(this.btnTurnon);
            this.Controls.Add(this.lblHeader);
            this.Name = "FireAlarmForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FireAlarmForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnTurnoff;
        private System.Windows.Forms.Button btnTurnon;
        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.Button btnBack;
    }
}