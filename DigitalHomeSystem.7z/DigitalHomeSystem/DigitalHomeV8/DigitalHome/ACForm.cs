﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DigitalHome
{
    public partial class ACForm : Form
    {
        /// <summary>
        /// device name
        /// </summary>
        private string deviceName;
        public ACForm(string deviceName)
        {
            InitializeComponent();

            this.deviceName = deviceName;

            //update GUI from database
            initializeData();
        }

        /// <summary>
        /// update GUI from database
        /// </summary>
        private void initializeData()
        {
            string connetionString;
            SqlConnection cnn;
            connetionString = @"Data Source=alizeh\sqlexpress;Initial Catalog=dighome_db;Integrated Security=SSPI;";
            cnn = new SqlConnection(connetionString);
            cnn.Open();

            //select command
            SqlCommand command = new SqlCommand("Select DeviceID, Status, Value from [Device] where DeviceName=@DeviceName", cnn);

            command.Parameters.AddWithValue("@DeviceName", deviceName);

            // execute
            using (SqlDataReader reader = command.ExecuteReader())
            {
                if (reader.HasRows)
                {
                    if (reader.Read())
                    {
                        if (reader.GetInt32(1) == 0)
                        {//off
                            btnACOff.Enabled = false;
                            btnACOn.Enabled = true;
                        }
                        else
                        {//on
                            btnACOff.Enabled = true;
                            btnACOn.Enabled = false;
                        }

                        //set value
                        txtTemp.Text = reader.GetString(2);
                    }
                }
            }

            //close connection
            cnn.Close();
        }


        private void btnBack_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void btnACOn_Click(object sender, EventArgs e)
        {
            string connetionString;
            SqlConnection cnn;
            connetionString = @"Data Source=alizeh\sqlexpress;Initial Catalog=dighome_db;Integrated Security=SSPI;";
            cnn = new SqlConnection(connetionString);
            cnn.Open();

            //select command
            SqlCommand command = new SqlCommand("Update Device set Status = 1 where DeviceName=@DeviceName", cnn);

            command.Parameters.AddWithValue("@DeviceName", deviceName);

            if (command.ExecuteNonQuery() > 0)
            {
                MessageBox.Show("Updated successfully");

                //on 
                btnACOff.Enabled = true;
                btnACOn.Enabled = false;
            }
            else
            {
                MessageBox.Show("Update failed");
            }

            //close connection
            cnn.Close();
        }

        private void btnACOff_Click(object sender, EventArgs e)
        {
            string connetionString;
            SqlConnection cnn;
            connetionString = @"Data Source=alizeh\sqlexpress;Initial Catalog=dighome_db;Integrated Security=SSPI;";
            cnn = new SqlConnection(connetionString);
            cnn.Open();
            //select command
            SqlCommand command = new SqlCommand("Update Device set Status = 0 where DeviceName=@DeviceName", cnn);

            command.Parameters.AddWithValue("@DeviceName", deviceName);

            if (command.ExecuteNonQuery() > 0)
            {
                MessageBox.Show("Updated successfully");

                //off 
                btnACOff.Enabled = false;
                btnACOn.Enabled = true;
            }
            else
            {
                MessageBox.Show("Update failed");
            }

            //close connection
            cnn.Close();
        }

        private void btnSetTemp_Click(object sender, EventArgs e)
        {
            string connetionString;
            SqlConnection cnn;
            connetionString = @"Data Source=alizeh\sqlexpress;Initial Catalog=dighome_db;Integrated Security=SSPI;";
            cnn = new SqlConnection(connetionString);
            cnn.Open();

            //select command
            SqlCommand command = new SqlCommand("Update Device set Value = @Value where DeviceName=@DeviceName", cnn);

            command.Parameters.AddWithValue("@Value", txtTemp.Text);
            command.Parameters.AddWithValue("@DeviceName", deviceName);

            if (command.ExecuteNonQuery() > 0)
            {
                MessageBox.Show("Updated successfully");
            }
            else
            {
                MessageBox.Show("Update failed");
            }

            //close connection
            cnn.Close();
        }

        private void txtTemp_TextChanged(object sender, EventArgs e)
        {

        }

        private void ACForm_Load(object sender, EventArgs e)
        {

        }
    }
}
