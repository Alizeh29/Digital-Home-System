﻿namespace DigitalHome
{
    partial class DoorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnlockoff = new System.Windows.Forms.Button();
            this.btnlockon = new System.Windows.Forms.Button();
            this.lblHeader = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnlockoff
            // 
            this.btnlockoff.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlockoff.Location = new System.Drawing.Point(236, 182);
            this.btnlockoff.Name = "btnlockoff";
            this.btnlockoff.Size = new System.Drawing.Size(106, 39);
            this.btnlockoff.TabIndex = 8;
            this.btnlockoff.Text = "Lock off";
            this.btnlockoff.UseVisualStyleBackColor = true;
            this.btnlockoff.Click += new System.EventHandler(this.btnlockoff_Click);
            // 
            // btnlockon
            // 
            this.btnlockon.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlockon.Location = new System.Drawing.Point(52, 182);
            this.btnlockon.Name = "btnlockon";
            this.btnlockon.Size = new System.Drawing.Size(106, 39);
            this.btnlockon.TabIndex = 7;
            this.btnlockon.Text = "Lock on";
            this.btnlockon.UseVisualStyleBackColor = true;
            this.btnlockon.Click += new System.EventHandler(this.btnlockon_Click);
            // 
            // lblHeader
            // 
            this.lblHeader.AutoSize = true;
            this.lblHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.lblHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeader.Location = new System.Drawing.Point(141, 58);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(96, 31);
            this.lblHeader.TabIndex = 6;
            this.lblHeader.Text = "DOOR";
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(52, 297);
            this.btnBack.Margin = new System.Windows.Forms.Padding(2);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(106, 36);
            this.btnBack.TabIndex = 9;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // DoorForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(397, 368);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnlockoff);
            this.Controls.Add(this.btnlockon);
            this.Controls.Add(this.lblHeader);
            this.Name = "DoorForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Door Form";
            this.Load += new System.EventHandler(this.DoorForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnlockoff;
        private System.Windows.Forms.Button btnlockon;
        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.Button btnBack;
    }
}