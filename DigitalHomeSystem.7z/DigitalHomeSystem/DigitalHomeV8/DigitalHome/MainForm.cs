﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DigitalHome
{
    public partial class MainForm : Form
    {
        private LoginForm loginForm;
        public MainForm(LoginForm loginForm)
        {
            this.loginForm = loginForm;
            InitializeComponent();
        }

        private void btnLivingroom_Click(object sender, EventArgs e)
        {
            LivingRoomForm form = new LivingRoomForm(this);
            this.Hide();
            form.ShowDialog();
            Visible = false;
            this.Show();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You have successfully logged out");
            loginForm.Visible = true;
            Dispose();
        }

        private void btnOutdoor_Click(object sender, EventArgs e)
        {
            OutdoorForm form = new OutdoorForm(this);
            this.Hide();
            form.ShowDialog();
            Visible = false;
            this.Show();
        }

        private void btnGarage_Click(object sender, EventArgs e)
        {
            GarageForm form = new GarageForm(this);
            this.Hide();
            form.ShowDialog();
            Visible = false;
            this.Show();
        }

        private void btnkitchen_Click(object sender, EventArgs e)
        {
            KitchenForm form = new KitchenForm(this);
            this.Hide();
            form.ShowDialog();
            Visible = false;
            this.Show();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void btnbathroom_Click(object sender, EventArgs e)
        {
            Bathroom bathroom = new Bathroom(this);
            this.Hide();
            bathroom.ShowDialog();
            Visible = false;
            this.Show();
        }

        private void btnbedroom_Click(object sender, EventArgs e)
        {
            Bedroom bedroom = new Bedroom(this);
            this.Hide();
            bedroom.ShowDialog();
            Visible = false;
            this.Show();
        }

        private void btnMasterBedroom_Click(object sender, EventArgs e)
        {
            MasterBedroom form = new MasterBedroom(this);
            this.Hide();
            form.ShowDialog();
            Visible = false;
            this.Show();
        }
    }
}
