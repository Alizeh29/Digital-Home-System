﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DigitalHome
{
    public partial class KitchenForm : Form
    {
        private MainForm mainForm;
        public KitchenForm(MainForm mainForm)
        {
            this.mainForm = mainForm;
            InitializeComponent();
        }

        private void btnOven_Click(object sender, EventArgs e)
        {
            Oven form = new Oven("kitchen oven");
            form.ShowDialog();
        }

        private void btnLight_Click(object sender, EventArgs e)
        {
            LightForm form = new LightForm("kitchen light");
            form.ShowDialog();
        }

        private void btnAC_Click(object sender, EventArgs e)
        {
            ACForm form = new ACForm("kitchen AC");
            form.ShowDialog();
        }

        private void btnCoffee_Click(object sender, EventArgs e)
        {
            Coffee form = new Coffee("kitchen coffee");
            form.ShowDialog();
        }

        private void btnStove_Click(object sender, EventArgs e)
        {
            Stove form = new Stove("kitchen stove");
            form.ShowDialog();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            mainForm.Visible = true;
            Dispose();
        }

        private void KitchenForm_Load(object sender, EventArgs e)
        {

        }
    }
}
