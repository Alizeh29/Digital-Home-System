﻿namespace DigitalHome
{
    partial class KitchenForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOven = new System.Windows.Forms.Button();
            this.btnLight = new System.Windows.Forms.Button();
            this.btnAC = new System.Windows.Forms.Button();
            this.btnCoffee = new System.Windows.Forms.Button();
            this.btnStove = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnOven
            // 
            this.btnOven.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOven.Location = new System.Drawing.Point(34, 171);
            this.btnOven.Margin = new System.Windows.Forms.Padding(2);
            this.btnOven.Name = "btnOven";
            this.btnOven.Size = new System.Drawing.Size(104, 44);
            this.btnOven.TabIndex = 0;
            this.btnOven.Text = "Oven";
            this.btnOven.UseVisualStyleBackColor = true;
            this.btnOven.Click += new System.EventHandler(this.btnOven_Click);
            // 
            // btnLight
            // 
            this.btnLight.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLight.Location = new System.Drawing.Point(178, 171);
            this.btnLight.Margin = new System.Windows.Forms.Padding(2);
            this.btnLight.Name = "btnLight";
            this.btnLight.Size = new System.Drawing.Size(105, 44);
            this.btnLight.TabIndex = 1;
            this.btnLight.Text = "Lights";
            this.btnLight.UseVisualStyleBackColor = true;
            this.btnLight.Click += new System.EventHandler(this.btnLight_Click);
            // 
            // btnAC
            // 
            this.btnAC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAC.Location = new System.Drawing.Point(322, 171);
            this.btnAC.Margin = new System.Windows.Forms.Padding(2);
            this.btnAC.Name = "btnAC";
            this.btnAC.Size = new System.Drawing.Size(106, 44);
            this.btnAC.TabIndex = 2;
            this.btnAC.Text = "AC";
            this.btnAC.UseVisualStyleBackColor = true;
            this.btnAC.Click += new System.EventHandler(this.btnAC_Click);
            // 
            // btnCoffee
            // 
            this.btnCoffee.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCoffee.Location = new System.Drawing.Point(78, 258);
            this.btnCoffee.Margin = new System.Windows.Forms.Padding(2);
            this.btnCoffee.Name = "btnCoffee";
            this.btnCoffee.Size = new System.Drawing.Size(127, 41);
            this.btnCoffee.TabIndex = 3;
            this.btnCoffee.Text = "Coffee Maker";
            this.btnCoffee.UseVisualStyleBackColor = true;
            this.btnCoffee.Click += new System.EventHandler(this.btnCoffee_Click);
            // 
            // btnStove
            // 
            this.btnStove.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStove.Location = new System.Drawing.Point(273, 258);
            this.btnStove.Margin = new System.Windows.Forms.Padding(2);
            this.btnStove.Name = "btnStove";
            this.btnStove.Size = new System.Drawing.Size(105, 41);
            this.btnStove.TabIndex = 4;
            this.btnStove.Text = "Stove";
            this.btnStove.UseVisualStyleBackColor = true;
            this.btnStove.Click += new System.EventHandler(this.btnStove_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.LightCoral;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(172, 55);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 31);
            this.label1.TabIndex = 5;
            this.label1.Text = "Kitchen";
            // 
            // btnBack
            // 
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(13, 357);
            this.btnBack.Margin = new System.Windows.Forms.Padding(4);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(110, 40);
            this.btnBack.TabIndex = 6;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // KitchenForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(476, 410);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnStove);
            this.Controls.Add(this.btnCoffee);
            this.Controls.Add(this.btnAC);
            this.Controls.Add(this.btnLight);
            this.Controls.Add(this.btnOven);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "KitchenForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "KitchenForm";
            this.Load += new System.EventHandler(this.KitchenForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnOven;
        private System.Windows.Forms.Button btnLight;
        private System.Windows.Forms.Button btnAC;
        private System.Windows.Forms.Button btnCoffee;
        private System.Windows.Forms.Button btnStove;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnBack;
    }
}