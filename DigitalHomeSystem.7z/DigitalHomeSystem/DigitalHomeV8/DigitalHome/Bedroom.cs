﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DigitalHome
{
    public partial class Bedroom : Form
    {
        private MainForm mainForm;
        public Bedroom(MainForm mainForm)
        {
            this.mainForm = mainForm;
            InitializeComponent();
        }

        private void btnAC_Click(object sender, EventArgs e)
        {
            ACForm form = new ACForm("bedroom AC");
            form.ShowDialog();
        }

        private void btnLight_Click(object sender, EventArgs e)
        {
            LightForm form = new LightForm("bedroom light");
            form.ShowDialog();
        }

        private void btnDoor_Click(object sender, EventArgs e)
        {
            DoorForm form = new DoorForm("bedroom door");
            form.ShowDialog();
        }

        private void btnWindow_Click(object sender, EventArgs e)
        {
            Window form = new Window("bedroom window");
            form.ShowDialog();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            mainForm.Visible = true;
            Dispose();
        }
    }
}
