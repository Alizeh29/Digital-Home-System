﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DigitalHome
{
    public partial class Bathroom : Form
    {
        private MainForm mainForm;
        public Bathroom(MainForm mainForm)
        {
            this.mainForm = mainForm;
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            mainForm.Visible = true;
            Dispose();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ACForm aC = new ACForm("bathroom AC");            
            aC.ShowDialog();
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LightForm door = new LightForm("bathroom light");
            door.ShowDialog();
           
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Window window = new Window("bathroom window");
            window.ShowDialog();
            
        }

        private void btnBathroomDoor_Click(object sender, EventArgs e)
        {
            DoorForm door = new DoorForm("bathroom door");
            door.ShowDialog();
           
        }

        private void btnShower_Click(object sender, EventArgs e)
        {
            Shower shower = new Shower("bathroom shower");
            shower.ShowDialog();
           
        }

        private void btnFaucet_Click(object sender, EventArgs e)
        {
            Faucet faucet = new Faucet("bathroom faucet");
            faucet.ShowDialog();
           
        }

        private void Bathroom_Load(object sender, EventArgs e)
        {

        }
    }
}
