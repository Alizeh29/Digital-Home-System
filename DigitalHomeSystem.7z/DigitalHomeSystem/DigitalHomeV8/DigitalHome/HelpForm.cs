﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DigitalHome
{
    public partial class HelpForm : Form
    {
        private LoginForm loginForm;

        public HelpForm(RegisterForm registerForm)
        {
            InitializeComponent();
        }

        public HelpForm(LoginForm loginForm)
        {
            this.loginForm = loginForm;
        }

        public HelpForm()
        {
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
