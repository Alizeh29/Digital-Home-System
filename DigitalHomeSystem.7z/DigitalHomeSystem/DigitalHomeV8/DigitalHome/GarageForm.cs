﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DigitalHome
{
    public partial class GarageForm : Form
    {
        private MainForm mainForm;

        public GarageForm(MainForm mainForm)
        {
            this.mainForm = mainForm;
            InitializeComponent();
        }

        private void Garage_Load(object sender, EventArgs e)
        {

        }

        private void btnLight_Click(object sender, EventArgs e)
        {
            LightForm form = new LightForm("garage light");
            form.ShowDialog();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            mainForm.Visible = false;
            Dispose();
          
        }

        private void btnGarageDoor_Click(object sender, EventArgs e)
        {
            DoorForm form = new DoorForm("garage door");
            form.ShowDialog();
        }

        private void btnMusic_Click(object sender, EventArgs e)
        {
            MusicForm form = new MusicForm("garage Music");
            form.ShowDialog();
        }

        private void btnAC_Click(object sender, EventArgs e)
        {
            ACForm form = new ACForm("garage AC");
            form.ShowDialog();
        }
    }
}
