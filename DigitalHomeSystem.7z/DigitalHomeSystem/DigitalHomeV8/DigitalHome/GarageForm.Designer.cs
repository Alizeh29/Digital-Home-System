﻿namespace DigitalHome
{
    partial class GarageForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLight = new System.Windows.Forms.Button();
            this.btnAC = new System.Windows.Forms.Button();
            this.btnGarageDoor = new System.Windows.Forms.Button();
            this.btnMusic = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.lblHeader = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnLight
            // 
            this.btnLight.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLight.Location = new System.Drawing.Point(38, 122);
            this.btnLight.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnLight.Name = "btnLight";
            this.btnLight.Size = new System.Drawing.Size(116, 51);
            this.btnLight.TabIndex = 0;
            this.btnLight.Text = "Lights";
            this.btnLight.UseVisualStyleBackColor = true;
            this.btnLight.Click += new System.EventHandler(this.btnLight_Click);
            // 
            // btnAC
            // 
            this.btnAC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAC.Location = new System.Drawing.Point(38, 190);
            this.btnAC.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnAC.Name = "btnAC";
            this.btnAC.Size = new System.Drawing.Size(116, 51);
            this.btnAC.TabIndex = 1;
            this.btnAC.Text = "AC";
            this.btnAC.UseVisualStyleBackColor = true;
            this.btnAC.Click += new System.EventHandler(this.btnAC_Click);
            // 
            // btnGarageDoor
            // 
            this.btnGarageDoor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGarageDoor.Location = new System.Drawing.Point(221, 122);
            this.btnGarageDoor.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnGarageDoor.Name = "btnGarageDoor";
            this.btnGarageDoor.Size = new System.Drawing.Size(116, 51);
            this.btnGarageDoor.TabIndex = 2;
            this.btnGarageDoor.Text = "Garage Door";
            this.btnGarageDoor.UseVisualStyleBackColor = true;
            this.btnGarageDoor.Click += new System.EventHandler(this.btnGarageDoor_Click);
            // 
            // btnMusic
            // 
            this.btnMusic.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMusic.Location = new System.Drawing.Point(221, 190);
            this.btnMusic.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnMusic.Name = "btnMusic";
            this.btnMusic.Size = new System.Drawing.Size(116, 51);
            this.btnMusic.TabIndex = 3;
            this.btnMusic.Text = "Music";
            this.btnMusic.UseVisualStyleBackColor = true;
            this.btnMusic.Click += new System.EventHandler(this.btnMusic_Click);
            // 
            // btnBack
            // 
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(38, 312);
            this.btnBack.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(79, 45);
            this.btnBack.TabIndex = 4;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lblHeader
            // 
            this.lblHeader.AutoSize = true;
            this.lblHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.lblHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeader.Location = new System.Drawing.Point(143, 43);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(104, 31);
            this.lblHeader.TabIndex = 11;
            this.lblHeader.Text = "Garage";
            // 
            // GarageForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(397, 368);
            this.Controls.Add(this.lblHeader);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnMusic);
            this.Controls.Add(this.btnGarageDoor);
            this.Controls.Add(this.btnAC);
            this.Controls.Add(this.btnLight);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "GarageForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Garage";
            this.Load += new System.EventHandler(this.Garage_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLight;
        private System.Windows.Forms.Button btnAC;
        private System.Windows.Forms.Button btnGarageDoor;
        private System.Windows.Forms.Button btnMusic;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label lblHeader;
    }
}