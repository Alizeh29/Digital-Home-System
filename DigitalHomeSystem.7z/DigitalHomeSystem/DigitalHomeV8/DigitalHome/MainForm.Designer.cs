﻿namespace DigitalHome
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGarage = new System.Windows.Forms.Button();
            this.btnLivingroom = new System.Windows.Forms.Button();
            this.lblHeader = new System.Windows.Forms.Label();
            this.btnOutdoor = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnbathroom = new System.Windows.Forms.Button();
            this.btnbedroom = new System.Windows.Forms.Button();
            this.btnkitchen = new System.Windows.Forms.Button();
            this.btnMasterBedroom = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnGarage
            // 
            this.btnGarage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGarage.Location = new System.Drawing.Point(211, 208);
            this.btnGarage.Margin = new System.Windows.Forms.Padding(4);
            this.btnGarage.Name = "btnGarage";
            this.btnGarage.Size = new System.Drawing.Size(141, 48);
            this.btnGarage.TabIndex = 8;
            this.btnGarage.Text = "Garage";
            this.btnGarage.UseVisualStyleBackColor = true;
            this.btnGarage.Click += new System.EventHandler(this.btnGarage_Click);
            // 
            // btnLivingroom
            // 
            this.btnLivingroom.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLivingroom.Location = new System.Drawing.Point(29, 208);
            this.btnLivingroom.Margin = new System.Windows.Forms.Padding(4);
            this.btnLivingroom.Name = "btnLivingroom";
            this.btnLivingroom.Size = new System.Drawing.Size(160, 48);
            this.btnLivingroom.TabIndex = 7;
            this.btnLivingroom.Text = "Living room";
            this.btnLivingroom.UseVisualStyleBackColor = true;
            this.btnLivingroom.Click += new System.EventHandler(this.btnLivingroom_Click);
            // 
            // lblHeader
            // 
            this.lblHeader.AutoSize = true;
            this.lblHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.lblHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeader.Location = new System.Drawing.Point(185, 58);
            this.lblHeader.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(197, 39);
            this.lblHeader.TabIndex = 6;
            this.lblHeader.Text = "Home Page";
            // 
            // btnOutdoor
            // 
            this.btnOutdoor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOutdoor.Location = new System.Drawing.Point(361, 208);
            this.btnOutdoor.Margin = new System.Windows.Forms.Padding(4);
            this.btnOutdoor.Name = "btnOutdoor";
            this.btnOutdoor.Size = new System.Drawing.Size(141, 48);
            this.btnOutdoor.TabIndex = 9;
            this.btnOutdoor.Text = "Outdoor";
            this.btnOutdoor.UseVisualStyleBackColor = true;
            this.btnOutdoor.Click += new System.EventHandler(this.btnOutdoor_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.Location = new System.Drawing.Point(211, 366);
            this.btnLogout.Margin = new System.Windows.Forms.Padding(4);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(141, 48);
            this.btnLogout.TabIndex = 10;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // btnbathroom
            // 
            this.btnbathroom.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbathroom.Location = new System.Drawing.Point(361, 281);
            this.btnbathroom.Margin = new System.Windows.Forms.Padding(4);
            this.btnbathroom.Name = "btnbathroom";
            this.btnbathroom.Size = new System.Drawing.Size(141, 48);
            this.btnbathroom.TabIndex = 13;
            this.btnbathroom.Text = "Bathroom";
            this.btnbathroom.UseVisualStyleBackColor = true;
            this.btnbathroom.Click += new System.EventHandler(this.btnbathroom_Click);
            // 
            // btnbedroom
            // 
            this.btnbedroom.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbedroom.Location = new System.Drawing.Point(211, 281);
            this.btnbedroom.Margin = new System.Windows.Forms.Padding(4);
            this.btnbedroom.Name = "btnbedroom";
            this.btnbedroom.Size = new System.Drawing.Size(141, 48);
            this.btnbedroom.TabIndex = 12;
            this.btnbedroom.Text = "Bedroom";
            this.btnbedroom.UseVisualStyleBackColor = true;
            this.btnbedroom.Click += new System.EventHandler(this.btnbedroom_Click);
            // 
            // btnkitchen
            // 
            this.btnkitchen.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnkitchen.Location = new System.Drawing.Point(29, 281);
            this.btnkitchen.Margin = new System.Windows.Forms.Padding(4);
            this.btnkitchen.Name = "btnkitchen";
            this.btnkitchen.Size = new System.Drawing.Size(160, 48);
            this.btnkitchen.TabIndex = 11;
            this.btnkitchen.Text = "Kitchen";
            this.btnkitchen.UseVisualStyleBackColor = true;
            this.btnkitchen.Click += new System.EventHandler(this.btnkitchen_Click);
            // 
            // btnMasterBedroom
            // 
            this.btnMasterBedroom.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMasterBedroom.Location = new System.Drawing.Point(176, 135);
            this.btnMasterBedroom.Margin = new System.Windows.Forms.Padding(4);
            this.btnMasterBedroom.Name = "btnMasterBedroom";
            this.btnMasterBedroom.Size = new System.Drawing.Size(215, 48);
            this.btnMasterBedroom.TabIndex = 14;
            this.btnMasterBedroom.Text = "Master Bedroom";
            this.btnMasterBedroom.UseVisualStyleBackColor = true;
            this.btnMasterBedroom.Click += new System.EventHandler(this.btnMasterBedroom_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(529, 453);
            this.Controls.Add(this.btnMasterBedroom);
            this.Controls.Add(this.btnbathroom);
            this.Controls.Add(this.btnbedroom);
            this.Controls.Add(this.btnkitchen);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.btnOutdoor);
            this.Controls.Add(this.btnGarage);
            this.Controls.Add(this.btnLivingroom);
            this.Controls.Add(this.lblHeader);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Home Page";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnGarage;
        private System.Windows.Forms.Button btnLivingroom;
        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.Button btnOutdoor;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnbathroom;
        private System.Windows.Forms.Button btnbedroom;
        private System.Windows.Forms.Button btnkitchen;
        private System.Windows.Forms.Button btnMasterBedroom;
    }
}