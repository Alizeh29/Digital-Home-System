﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace DigitalHome
{
    public partial class DoorForm : Form
    {
        /// <summary>
        /// device name
        /// </summary>
        private string deviceName;

        public DoorForm(string deviceName)
        {
            InitializeComponent();

            this.deviceName = deviceName;

            //update GUI from database
            initializeData();

            if (LoginForm.child)
            {
                btnlockon.Enabled = false;
                btnlockoff.Enabled = false;
            }
        }

        /// <summary>
        /// update GUI from database
        /// </summary>
        private void initializeData()
        {
            string connetionString;
            SqlConnection cnn;
            connetionString = @"Data Source=alizeh\sqlexpress;Initial Catalog=dighome_db;Integrated Security=SSPI;";
            cnn = new SqlConnection(connetionString);
            cnn.Open();

            //select command
            SqlCommand command = new SqlCommand("Select DeviceID, Status, Value from [Device] where DeviceName=@DeviceName", cnn);

            command.Parameters.AddWithValue("@DeviceName", deviceName);

            // execute
            using (SqlDataReader reader = command.ExecuteReader())
            {
                if (reader.HasRows)
                {
                    if (reader.Read())
                    {
                        if (reader.GetInt32(1) == 0)
                        {//off
                            btnlockoff.Enabled = false;
                            btnlockon.Enabled = true;
                        }
                        else
                        {//on
                            btnlockoff.Enabled = true;
                            btnlockon.Enabled = false;
                        }
                    }
                }
            }

            //close connection
            cnn.Close();
        }

        /// <summary>
        /// close form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnBack_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void btnlockoff_Click(object sender, EventArgs e)
        {
            string connetionString;
            SqlConnection cnn;
            connetionString = @"Data Source=alizeh\sqlexpress;Initial Catalog=dighome_db;Integrated Security=SSPI;";
            cnn = new SqlConnection(connetionString);
            cnn.Open();

            //select command
            SqlCommand command = new SqlCommand("Update Device set Status = 0 where DeviceName=@DeviceName", cnn);

            command.Parameters.AddWithValue("@DeviceName", deviceName);

            if (command.ExecuteNonQuery() > 0)
            {
                MessageBox.Show("Updated successfully");

                btnlockoff.Enabled = false;
                btnlockon.Enabled = true;
            }
            else
            {
                MessageBox.Show("Update failed");
            }

            //close connection
            cnn.Close();
        }

        private void btnlockon_Click(object sender, EventArgs e)
        {
            string connetionString;
            SqlConnection cnn;
            connetionString = @"Data Source=alizeh\sqlexpress;Initial Catalog=dighome_db;Integrated Security=SSPI;";
            cnn = new SqlConnection(connetionString);
            cnn.Open();

            //select command
            SqlCommand command = new SqlCommand("Update Device set Status = 1 where DeviceName=@DeviceName", cnn);

            command.Parameters.AddWithValue("@DeviceName", deviceName);

            if (command.ExecuteNonQuery() > 0)
            {
                MessageBox.Show("updated sucessfully");
                                
                btnlockoff.Enabled = true;
                btnlockon.Enabled = false;

                if (deviceName == "outdoor door")
                {
                    HomeForm.timer.Enabled = true;
                }
            }
            else
            {
                MessageBox.Show("Update failed");
            }

            //close connection
            cnn.Close();
        }

        private void DoorForm_Load(object sender, EventArgs e)
        {

        }
    }
}
